<?php
if(!defined('IN_CRONLITE'))exit();
include_once TEMPLATE_ROOT.'faka/inc/waphead.php';
?>
<div style="height: 50px"></div>
<div class="menux"><div align="center">联系我们</div></div>

<div class="baoliao" style="padding:20px;">
	<div class="user_top gekai">
		<br>
		<br>
	   <span style="font-size: 16px; white-space: normal;" class="ziti"><?php echo $conf['gg_search'];?></span>
		<p class="ziti">
                <span style="color: #cccccc">-------------------------------------------------------------</span>
                <br>
                <br>
                <img src="assets/faka/images/qq_s.png" width="22" title="">&ensp;QQ或通知群：<a target="blank" href="https://qm.qq.com/q/1OXOoREmQc"><?php echo $conf['kfqq']?></a>
				<br><br>
                <span style="color: #cccccc">-------------------------------------------------------------</span>
				<?php if(!empty($conf['kfwx'])){?><br>
                <br>
                <img src="assets/faka/images/qq_wx.png" width="22" title="">&ensp;微信客服：<?php echo $conf['kfwx']?>
				<br><br>
                <span style="color: #cccccc">-------------------------------------------------------------</span><?php }?>
		</p>
		<!-- 新增联系方式 -->
		<p class="ziti">
                <br>
                <br>
                <h1>【下方频道只用于通知，不会涉及销售，代理可放心】</h1>
                <img src="favicon.ico" width="22" title="">&ensp;神秘频道：<a target="blank" href="https://t.me/guanianqq">@guanianqq</a>
				<br><br>
                <span style="color: #cccccc">-------------------------------------------------------------</span>
				<br>
             
        </p>
	</div>
</div>

<?php include TEMPLATE_ROOT.'faka/inc/wapfoot.php';?>
</body>
</html>