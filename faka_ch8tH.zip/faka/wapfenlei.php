<?php 
if(!defined('IN_CRONLITE'))exit();

$data=$DB->getAll("SELECT * FROM pre_class WHERE active=1 order by sort asc");
$count = count($data);
include_once TEMPLATE_ROOT.'faka/inc/waphead.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>售后保障说明</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .menux {
            background-color: #ffffff;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .search_input {
            width: 70%;
            padding: 8px;
            margin-right: 5px;
        }
        .search_submit {
            padding: 8px 15px;
            color: white;
            background-color: #f44530;
            border: none;
            cursor: pointer;
        }
        .aftersales {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .aftersales h3, .aftersales h4, .aftersales h5 {
            color: #333;
            margin-top: 20px;
        }
        .aftersales p {
            margin-top: 10px;
        }
        .aftersales ol {
            margin-left: 20px;
        }
        .aftersales ol ol {
            margin-left: 20px;
        }
        .aftersales hr {
            border: 0;
            height: 1px;
            background-color: #eaeaea;
            margin: 20px 0;
        }
        .m_user {
            height: 100px;
            text-align: center;
            padding-top: 40px;
            background-color: #f4f4f4;
        }
        .m_user a {
            color: #0000EE;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="container">
    <div style="height: 50px"></div>

    <?php if($conf['search_open']==1){?>
    <div class="menux">
        <form action="?" method="get">
            <input type="hidden" name="mod" value="wapso"/>
            <input name="kw" type="text" class="search_input" placeholder="请输入您要查询的商品名称关键词" required>
            <input type="submit" class="search_submit" value="商品搜索">
        </form>
    </div>
    <?php }?>

    <div class="menux"><div align="center">售后保障说明</div></div>

    <div class="aftersales">
        <h3>我们的售后承诺：</h3>
        <p>本站购买的部分API均提供保障售后，只需要在后台提交工单提供骗子跑路凭证【具体】，我们审核通过后可以给您及时更换API，帮助您及时止损。您可以放心购买和使用我们的API服务。</p>
        <hr>
        <h4>详细售后政策如下：</h4>
        <ol>
            <li>
                <h5>一、产品概述</h5>
                <p>本平台所出售的虚拟卡，是专门为满足特定数字业务需求而设立的数字化产品，主要用于储存游戏数据以及促进电商业务交流等合法用途。该虚拟卡不具备电话通讯及短信发送功能，旨在确保其在既定业务范围内安全、高效地发挥作用。</p>
            </li>
            <li>
                <h5>二、合规使用提醒</h5>
                <p>用户在使用本虚拟卡过程中，应严格遵守国家相关法律法规及平台规定，不得将其用于任何违规违法活动。如发现有任何违反法律法规的情况，GN转码平台将积极配合相关部门进行调查处理，全力履行应尽的社会责任。</p>
            </li>
            <li>
                <h5>三、售后范围界定</h5>
                <ol type="a">
                    <li><p>若因平台系统故障或技术原因导致虚拟卡与邮件记录交互出现异常，本平台将负责排查故障原因，并在合理时间内采取有效措施予以解决，确保用户能够正常获取相关邮件记录。</p></li>
                    <li><p>对于因平台进行风险控制措施调整或附带项目变更等因素，对虚拟卡使用产生影响的情况，本平台将提前通过官方公告、短信通知等合理方式告知用户相关变更信息，并根据具体情况提供相应的应对方案或协助措施，以保障用户的合法权益。</p></li>
                </ol>
            </li>
            <li>
                <h5>四、非售后范围明确</h5>
                <ol type="a">
                    <li><p>鉴于业务特性，出售的虚拟卡可能会出现少量二次重启老号的情况，此属于正常业务现象，不在本平台售后范围之内。用户在获取虚拟卡时应知晓并接受这一情况。</p></li>
                    <li><p>若虚拟卡出现号码异常、因外部风险控制因素导致受限或因平台常规风险控制措施而受到限制等各类情况，由于此类情况多涉及复杂的外部环境及平台整体风险管控要求，故不在本平台售后范围之内。用户应自行了解并掌握并遵守相关风险控制规定，合理安排虚拟卡的使用。</p></li>
                </ol>
            </li>
            <li>
                <h5>五、客户沟通规范</h5>
                <p>本平台倡导客户与我们进行理性、文明的沟通。若客户在售后诉求处理过程中出现无理纠缠、恶意扯皮等不符合正常售后沟通规范的行为，经核实后，本平台有权采取限制购买权限等措施，以维护平台正常的售后秩序和运营环境。</p>
            </li>
        </ol>
        <hr>
    </div>

    <div class="m_user">
        <a href="#">返回顶部</a>
    </div>
</div>

<?php include TEMPLATE_ROOT.'faka/inc/wapfoot.php';?>
</body>
</html>